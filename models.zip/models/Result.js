const mongoose = require("mongoose");

const ResultSchema = new mongoose.Schema({
    noteId: { type: mongoose.Schema.Types.ObjectId, ref: "Note" },
    userId: { type: String, required: true },  // 👈 new field
    title: String,
    summary: String,
    flashcards: String,
    quizzes: String,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Result", ResultSchema);
