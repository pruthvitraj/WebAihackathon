const express = require("express");
const Note = require("../models/Note");
const Result = require("../models/Result");
const router = express.Router();
const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

router.get("/", async (req, res) => {
    if (!req.session.user) {
        req.session.error = "Please log in to access this page.";
        return res.redirect("/api/auth/login");
    }

    const { noteId, title } = req.query;
    if (!noteId) return res.send("Note ID is required");

    try {
        const note = await Note.findById(noteId);
        if (!note) return res.send("Note not found");

        const text = note.extractedText || "";
        if (!text.trim()) return res.send("No text extracted from this file");

        // Gemini AI model
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        // Combined prompt
        const prompt = `
Please process the following text and provide three separate sections:

1. SUMMARY: A concise summary of the text.
2. FLASHCARDS: 5 Q&A flashcards, format each as "Q: ... A: ..."
3. QUIZZES: 5 multiple-choice questions, format each as "Question: ... a) ... b) ... c) ... d) ... Answer: ..."

Text:
${text}
`;

        const combinedRes = await model.generateContent(prompt);
        const combinedText = combinedRes.response.text();

        // Parse sections
        let summary = "";
        let flashcards = "";
        let quizzes = "";

        const summaryMatch = combinedText.match(/SUMMARY:(.*?)FLASHCARDS:/s);
        if (summaryMatch) summary = summaryMatch[1].trim();

        const flashcardsMatch = combinedText.match(/FLASHCARDS:(.*?)QUIZZES:/s);
        if (flashcardsMatch) flashcards = flashcardsMatch[1].trim();

        const quizzesMatch = combinedText.match(/QUIZZES:(.*)/s);
        if (quizzesMatch) quizzes = quizzesMatch[1].trim();

        // Save result
        const result = new Result({
            noteId,
            userId: req.session.user.id,
            title: title || `Result for ${note.fileName}`,
            summary,
            flashcards,
            quizzes
        });
        await result.save();

        // Render page using only the current result
        res.render("dashboard", {
            user: req.session.user,
            summaries: [{ _id: result._id, title: result.title, text: result.summary }],
            flashcards: [result.flashcards],
            quizzes: [result.quizzes],
            history: [result],
            progress: {
                totalNotes: 1,
                totalSummaries: summary ? 1 : 0,
                totalFlashcards: flashcards ? 1 : 0,
                totalQuizzes: quizzes ? 1 : 0
            }
        });

    } catch (err) {
        console.error("Error generating content:", err);
        res.status(500).send("Error generating content");
    }
});

module.exports = router;
