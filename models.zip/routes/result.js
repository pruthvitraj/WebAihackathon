const express = require("express");
const Result = require("../models/Result");

const router = express.Router();

// 📌 User-specific history
router.get("/history", async (req, res) => {
    try {
        // check login
        if (!req.session.user) {
            return res.redirect("/api/auth/login");
        }

        const userId = req.session.user.id;

        // fetch only results of this user
        const results = await Result.find({ userId }).sort({ createdAt: -1 });

        res.render("history", { results, user: req.session.user });
    } catch (err) {
        console.error("History error:", err);
        res.send("Error loading history");
    }
});

// 📌 User-specific result detail
router.get("/:id", async (req, res) => {
    try {
        if (!req.session.user) {
            return res.redirect("/api/auth/login");
        }

        const userId = req.session.user.id;

        // fetch only if result belongs to user
        const result = await Result.findOne({ _id: req.params.id, userId });
        if (!result) {
            return res.send("Result not found or not authorized");
        }

        res.render("resultDetail", { result, user: req.session.user });
    } catch (err) {
        console.error("Result detail error:", err);
        res.send("Error loading result");
    }
});

module.exports = router;
