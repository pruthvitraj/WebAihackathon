const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // for form POST requests
app.use(express.json());

const session = require("express-session");

app.use(session({
    secret: "yourSecretKey",
    resave: false,
    saveUninitialized: true
}));

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Serve static files (CSS/JS)
app.use(express.static(path.join(__dirname, "public")));
// app.use(express.static(path.join(__dirname, "public")));


// Connect MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.log("❌ DB Error:", err));

// Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/upload", require("./routes/upload"));
app.use("/api/generate", require("./routes/generate"));
app.use("/api/result", require("./routes/result"));
// app.use("/api/dashboard", require("./routes/dashboard"));
// app.use("/api/progress", require("./routes/progress"));
console.log("Session user:", app.request ? app.request.session : "No request object");
app.get("/api/dashboard", (req, res) => {
    console.log("Session user in dashboard:", req.session.user);

    res.render("dashboard", {
        user: req.session.user || null,
        summaries: [],       // No summaries yet
        flashcards: [],      // No flashcards yet
        quizzes: [],         // No quizzes yet
        history: [],         // No activity yet
        progress: null       // No progress yet
    });
});

// Start Server
app.get("/", (req, res) => {
   res.render("Home", { user: req.session.user || null });
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
